<div class="box">
    <div class="box-title c"><h1><i class="fa fa-table"></i>评审专家信息填写</h1>
      </div><!--box-title end-->
    <div class="box-content">
        <div class="show_menu">评审专家学校本学科信息设置</div>
        <div class="box-table">
            <?php  $form = $this->beginWidget('CActiveForm', get_form_list()); ?>
            <table border="1" cellspacing="1" cellpadding="0" class="product_publish_content" style="width:100%;margin-bottom:10px;">
        <?php 
         $s1="f_sname,f_tname;f_position,f_idno;f_bankname,f_account;f_mobile,f_memo";
         echo BaseLib::model()->show_td($form,$model,$s1,'1');//自动换行
      ?>

                <tr id="fujian1">
                    <td colspan="1" style="text-align: center"><?php echo $form->label($model, 'signature'); ?><span class="required">*</span></td>
                    <td colspan="3">
                        <?php echo $form->hiddenField($model, 'signature', array('class' => 'input-text fl')); ?>
                        <?php echo show_pic($model->signature,get_class($model).'_'.'signature')?>
                        <div> <script>we.uploadpic('<?php echo get_class($model);?>_signature', 'jpg');</script></div>
                        <?php echo $form->error($model, 'signature', $htmlOptions = array()); ?>
                    </td>
                </tr>
        <tr style="text-align:center;">
            <td colspan="4" style="text-align:center;padding:20px;">

                <button onclick="save()" herf="javascript:;" class="btn btn-blue">保存</button>
                <!--                <button class="btn btn-blue" type="submit">保存</button>-->
<!--                <button class="btn" type="button" onclick="we.back();">取消</button>-->
            </td>
        </tr>
</table>
            <?php $this->endWidget(); ?>
        </div><!--box-table end-->
    </div><!--box-content end-->
</div><!--box end-->
<script>
we.tab('.box-detail-tab li','.box-detail-tab-item');
</script>
<script>
    var deleteUrl = '<?php echo $this->createUrl('delete', array('id' => 'ID')); ?>';
    $(function(){
        let api = $.dialog.open.api;	// 			art.dialog.open扩展方法
        api.button(
            {
                name: '取消'
            }
        );
        $('.box-table tbody tr').on('click', function(){
            // console.log($(this).attr('data-id'))
            if($(this).attr('data-id')){
                $.dialog.data('id',$(this).attr('data-id'));
                $.dialog.close();
            }
        });
    });
</script>
<script>
//    $tid是被审核人的id，$f_auditcode是评审码
    var t = '<?php echo $tid;?>';
    var auditcode='<?php echo $f_auditcode;?>'
        function save() {
            console.log(t);
            var form = $('#active-form').serialize();
        var Turl='<?php echo $this->createUrl('SaveExpert')?>&'+form;
        Turl=Turl+'&f_auditcode='+auditcode+'&tid='+t;
            console.log("Turl:",Turl);
            $.ajax({
            type: 'get',
            url: Turl,
            dataType: 'json',
            success: function(data){
                console.log(data)
                $.dialog.data('mydata', data);
                $.dialog.close();
            },
            error: function(request){
                console.log('错误');
            }
        });

    }

</script>