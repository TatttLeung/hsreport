<style>
    #answerbox_1 .cke_contents{height:120px!important;}
    #answerbox_2 .cke_contents{height:80px!important;}
    #answerbox_5 .cke_contents{height:70px!important;}
</style>
<div class="box">
    <div class="box-title c">
        <h2>
            <i class="fa fa-table"></i>
            当前界面：题目修改》
            <span style="color:DodgerBlue">题目修改</span></h2>
            <span class="back">
             <?php //echo BackTo($this,'BaseInfo/Updatecheck',get_session('BaseInfoId'),'返回');?>
            </span>
        </h2>
    </div><!--box-title end-->
    <?php  $form = $this->beginWidget('CActiveForm', get_form_list());?>
        <div class="box-detail">
            <div style="display:block;" class="box-detail-tab-item">
                <table>
                 <?php echo Base_level::model()->downSelect($form,$model,'[levelname'); ?>
                 
                 <?php echo Basecode::model()->chapterSelect($form,$model,'chapters'); ?>
                 <?php echo Basecode::model()->sectionSelect($form,$model,'sections]'); ?>

                 <?php echo Questype::model()->downSelect($form,$model,'[questiontype_char'); ?>
                 <?php echo Knowslevel::model()->downSelect($form,$model,'questionlevel'); ?>
                 <?php echo Sections::model()->downSelect($form,$model,'sections]'); ?>
                
                <?php 
                 echo BaseLib::model()->tdInput($form,$model,'[]questionURL:1:5');

                 echo BaseLib::model()->edit($form,$model,'[]question:1:5');
                 
                 echo BaseLib::model()->edit($form,$model,'[]questionselect:1:5');
                 // put_msg($model->questionselect_temp);
                  // put_msg('line 32');
                  //    put_msg($model->answertext_temp);
                ?>
               <tr><td colspan="6" align="center">
               <?php 
                  $tmp=Questype::model()->findAll("quest_demo<>' ' order by questcode");
                  foreach($tmp as $v){
                    $s1='<button class="btn" type="button" onclick="chosequestype(';
                    $s1.="'".$v->questype."','". base64_encode($v->quest_demo)."'";
                    $s1.=');">添加'.$v->questype.' </button>';
                    echo $s1.chr(13).chr(10);
                  }
                ?>
               </td></tr>
                <?php 
                 echo BaseLib::model()->edit($form,$model,'[]answertext:1:5');
                ?>
              </table>
              
            </div><!--box-detail-tab-item end   style="display:block;"-->
            
        </div><!--box-detail-bd end-->
        <div style="display:block;" class="box-detail-tab-item">
        <?php echo show_shenhe_box(array('baocun'=>'保存'));?>      
        <button class="btn" type="button" onclick="we.back();">取消</button></div>
    <?php $this->endWidget(); ?>
    </div><!--box-detail end-->
</div><!--box end-->

<script>

function chosequestype(pname,pmemo){
 var content;
 var ue =UE.getEditor('editor_Questions_questionselect_temp');
   ue.ready(function () {
   content =this.getContent()+'<p>'+base64Decode(pmemo)+'</p>';
  this.setContent(content);
  }); 
}

 function base64Decode(input){
                rv = window.atob(input);
                rv = escape(rv);
                rv = decodeURIComponent(rv);
                return rv;
        }


</script>