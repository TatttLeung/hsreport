<body>
<style>
    #answerbox_1 .cke_contents{height:80px!important;}
    #answerbox_2 .cke_contents{height:80px!important;}
    #answerbox_5 .cke_contents{height:80px!important;}
    #answerbox_99 .cke_contents{height:80px!important;}
</style>
<link rel="stylesheet" type="text/css" href="/hkam/hsyii/static/admin/css/public.css" />
<link rel="stylesheet" type="text/css" href="/hkam/hsyii/static/admin/css/font.css" />
<link rel="stylesheet" type="text/css" href="/hkam/hsyii/static/admin/css/style.css" />
<link rel="stylesheet" type="text/css" href="/hkam/hsyii/static/admin/js/jquery.fallr/jquery.fallr.css" />
<link rel="stylesheet" type="text/css" href="/hkam/hsyii/static/admin/js/jquery.datetimepicker/jquery.datetimepicker.css" />
<link rel="stylesheet" type="text/css" href="/hkam/hsyii/static/admin/js/jquery.uploadifive/uploadifive.css" />
<link rel="stylesheet" type="text/css" href="/hkam/hsyii/static/admin/js/artDialog/skins/default.css" />
<link rel="stylesheet" type="text/css" href="/hkam/hsyii/static/admin/js/jquery.contextMenu/jquery.contextMenu.css" />
<link rel="stylesheet" type="text/css" href="/hkam/app/core/styles/css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="/hkam/app/core/styles/css/jquery-ui.min.css" />
<link rel="stylesheet" type="text/css" href="/hkam/app/core/styles/css/peskin.css" />
<script type="text/javascript" src="/hkam/hsyii/assets/7c719ce1/jquery.min.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/jquery.nicescroll.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/jquery.fallr/jquery.fallr.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/ueditor/ueditor.config.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/ueditor/ueditor.all.min.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/ueditor/lang/zh-cn/zh-cn.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/ueditor/ueditor.parse.min.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/jquery.datetimepicker/jquery.datetimepicker.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/jquery.uploadifive/jquery.uploadifive.min.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/My97DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/artDialog/jquery.artDialog.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/artDialog/plugins/iframeTools.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/jquery.contextMenu/jquery.ui.position.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/jquery.contextMenu/jquery.contextMenu.js"></script>
<script type="text/javascript" src="/hkam/hsyii/static/admin/js/PCASClass.js"></script>
<script type="text/javascript" src="/hkam/app/core/styles/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="/hkam/app/core/styles/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/hkam/app/core/styles/js/bootstrap-datetimepicker.js"></script>
<script type="text/javascript" src="/hkam/app/core/styles/js/all.fine-uploader.min.js"></script>

<script type="text/javascript" src="/hkam/app/core/styles/js/plugin.js"></script>
<div class="container-fluid">
    <div class="row-fluid">
        <div class="main">
    <?php $form = $this->beginWidget('CActiveForm', get_form_list()); ?>
     
            <div class="col-xs-2" style="padding-top:10px;margin-bottom:0px;"></div>
    <div class="col-xs-10" id="datacontent">
                <div class="box itembox" style="margin-bottom:0px;border-bottom:1px solid #CCCCCC;">
                    <div class="col-xs-12">
                        <ol class="breadcrumb">
                            <li class="active">修改普通試題</li>
                            <label class="control-label col-sm-1">科目:</label>
                            <?php  echo $model->subjectid_name; ?>
                        <a class="btn btn-primary pull-right" href="index.php?{x2;$_app}-master-questions">普通試題管理</a>
                        </ol>
                    </div>
                </div>
    <div class="box itembox" style="padding-top:10px;margin-bottom:0px;">
        <form action="index.php?exam-master-questions-modify" method="post" class="form-horizontal">
        <fieldset>
                        
        <div class="form-group">
            <label class="control-label col-sm-1">
            <?php echo $form->labelEx($model, 'levelid'); ?></label>
            <div class="col-sm-1">
             <?php 
             $levels=Base_level::model()->findAll();
             echo dropDownList($model,'levelid',$levels,'f_id','F_NAME');?>
             </div>
            <label class="control-label col-sm-1">章:</label>
            <div class="col-sm-3">
             <?php 
             $chapters=Base_level::model()->findAll();
             echo dropDownList($model,'chapter',$chapters,'f_id','F_NAME');?>
            </div>
              
            <label class="control-label col-sm-1"><?php echo $form->labelEx($model, 'sectionid'); ?>:</label>
            <div class="col-sm-3">
            <?php 
             $Sections=Sections::model()->findAll();
            echo dropDownList($model,'sectionid',$Sections,'sectionid','section');?>
            </div>
        </div>
        <div class="form-group">
        <label class="control-label col-sm-1"><?php echo $form->labelEx($model, 'questiontype'); ?></label>
        <div class="col-sm-2">
         <?php 
          $questypes=Questype::model()->findAll();
         echo dropDownList($model,'questiontype',$questypes,'questid','questype');?>
        </div>

            
        <label class="control-label col-sm-1">
       <?php echo $form->labelEx($model, 'questionlevel'); ?>
        </label>
         <div class="col-sm-1">
            <?php 
            $Knowslevels=Knowslevel::model()->findAll();
            echo dropDownList($model,'questionlevel',$Knowslevels,'klid','klname');?>
        </div> 
            
      </div>
        <div class="form-group">
             <label class="control-label col-sm-1">
             <?php echo $form->labelEx($model, 'question'); ?></label>
            <div class="col-sm-11">
             <?php echo texteditor($form,$model, 'question');?>
            </div>
        </div>

        <div class="form-group" id="selecttext" style="display:none;">
            <label class="control-label col-sm-1"><p align="left">備選</p><p align="left">擇項</p></label>
            <div class="col-sm-11">
                <?php echo texteditor($form,$model, 'questionselect');?>
                <span class="help-block">無選擇項的請不要填寫，如填空題、問答題等主觀題。</span>
            </div>
        </div>


    <div class="form-group">
        <label class="control-label col-xs-1">
            <p align="left">參&nbsp;&nbsp;考</p>
            <p align="left">答&nbsp;&nbsp;案</p>
            <p align="left">答案數：</p>
            <p align="left">
            <?php 
            $selectorder=BaseCode::model()->selectNum();
            $ck='onchange="javascript:setSelectnumber(';
            $ck="$(this).find('option:selected').attr('rel'));".'"';
            echo dropDownList($model,'answernum',$selectorder,'id','value',$ck);?>
            </p>
        </label>

    <div class="col-sm-11">
        <div id="answerbox_1" class="answerbox" style="display:none;">
          <?php for($i=1;$i<4;$i++){
            $v= $selectorder[$i-1]['name'];
            ?>
            <label class="control-label col-sm-1"><?php echo $v;?></label>
             <div class="col-sm-11"  >
                <?php echo texteditor($form,$model, 'sele1');?>
             </div>
            <?php }?>
            <label class="control-label col-sm-1"><p align="center">答案</p></label>          
            <div class="col-sm-11">
            <?php echo texteditor($form,$model, 'anstext1');?>
            </div>
            <label class="control-label col-sm-1"><p align="center">知識點</p></label>         
            <div class="col-sm-11">
            <?php echo radioButtonList($form,$model,'answer1','','ABC','');?>
            </div>
        </div>
        <div id="answerbox_2" class="answerbox" style="display:none;">
          <?php for($i=1;$i<5;$i++){
            $v= $selectorder[$i-1]['name'];
            ?>
            <label class="control-label col-sm-1"><?php echo $v;?></label>
             <div class="col-sm-11"  >
                <?php echo texteditor($form,$model, 'sele2');?>
             </div>
            <?php }?>
            <label class="control-label col-sm-1"><p align="center">答案</p></label>
            <div class="col-sm-11">
            <?php echo checkBoxList($form,$model,'answer2','','ABC','');?>
            </div>  
            <label class="control-label col-sm-1"><p align="center">知識點</p></label>         
            <div class="col-sm-11">
            <?php echo texteditor($form,$model, 'anstext2');?>
            </div>
        
        </div>

        <div id="answerbox_3" class="answerbox" style="display:none;">
            <div class="col-sm-12">
            <?php for($i=1;$i<2;$i++){
            $v= $selectorder[$i-1]['name'];
            ?>
            <label class="control-label col-sm-1"><?php echo $v;?></label>
             <div class="col-sm-11"  >
                <?php echo texteditor($form,$model, 'sele3');?>
             </div>
            <?php }?>
            <label class="control-label col-sm-1"><p align="center">答案</p></label>          
            <div class="col-sm-11">
            <?php echo radioButtonList($form,$model,'answer3','','Rw','');?>
            </div>
            <label class="control-label col-sm-1"><p align="center">知識點</p></label>         
            <div class="col-sm-11">
            <?php echo texteditor($form,$model, 'anstext3');?>
            </div>
        </div>
    <div id="answerbox_5" class="answerbox" style="display:none;">
      <?php for($i=1;$i<9;$i++){
            $v= $selectorder[$i-1]['name'];
      ?>
          <div id="answerbox_5<?php echo $i;?>" style="display:none;">
          <label class="control-label col-sm-1"><p align="center">答案<?php echo $i;?></p>
           <p align="center">占題分
             <?php echo $form->textField($model, 'score5', array('class' => 'input-text')); ?>
             <?php echo $form->error($model, 'score5', $htmlOptions = array()); ?>
          </p>    
        </label>
        <div class="col-sm-11">
          <?php echo texteditor($form,$model, 'answer5');?>
         </div>
        <label class="control-label col-sm-1"><p align="center">知識點{x2;v:sid}</p></label>
         <div class="col-sm-11">
            <?php echo texteditor($form,$model, 'anstext5');?>
          </div>
       </div>
     <?php }?>
 
   </div>

    <div id="answerbox_10" class="answerbox" style="display:none;">
        <label for="backpicture" class="control-label col-sm-1"> <p align="left">背景</p></label>
          <div class="col-sm-4">
          <script type="text/template" id="pe-template-backpicture">
            <div class="qq-uploader-selector" style="width:90%" qq-drop-area-text="可將圖片拖拽至此處上傳" style="clear:both;">
              <div class="qq-upload-button-selector" style="clear:both;">
                  <ul class="qq-upload-list-selector list-unstyled" aria-live="polite" aria-relevant="additions removals" style="clear:both;">
                      <li class="text-center">
                      <div class="thumbnail">
                <img class="qq-thumbnail-selector" alt="點擊上傳新圖片">
                <input type="hidden" class="qq-edit-filename-selector" name="args[backpicture]" tabindex="0">
              </div>
                      </li>
                    </ul>
                    <ul class="qq-upload-list-selector list-unstyled" aria-live="polite" aria-relevant="additions removals" style="clear:both;">
                    <li class="text-center">
                      <div class="thumbnail">
                <img class="qq-thumbnail-selector" src="{x2;$question['backpicture']}" alt="點擊上傳新圖片">
                <input type="hidden" class="qq-edit-filename-selector" name="args[backpicture]" tabindex="0" value="{x2;$question['backpicture']}">
                </div>
                    </li>
                  </ul>
                </div>
              </div>
          </script>
          <div class="fineuploader" attr-type="thumb" attr-template="pe-template-backpicture"></div>
        </div>
        <label for="backpicture" class="control-label col-sm-2"><p align="left">標準圖</p></label>
        <div class="col-sm-5">
          <script type="text/template" id="pe-template-questionpicture">
          <div class="qq-uploader-selector" style="width:90%" qq-drop-area-text="可將圖片拖拽至此處上傳" style="clear:both;">
              <div class="qq-upload-button-selector" style="clear:both;">
                <ul class="qq-upload-list-selector list-unstyled" aria-live="polite" aria-relevant="additions removals" style="clear:both;">
                  <li class="text-center">
                      <div class="thumbnail">
                <img class="qq-thumbnail-selector" alt="點擊上傳新圖片">
                <input type="hidden" class="qq-edit-filename-selector" name="args[questionpicture]" tabindex="0">
              </div>
                  </li>
                  </ul>
                  <ul class="qq-upload-list-selector list-unstyled" aria-live="polite" aria-relevant="additions removals" style="clear:both;">
                  <li class="text-center">
                      <div class="thumbnail">
                <img class="qq-thumbnail-selector" src="{x2;$question['questionpicture']}" alt="點擊上傳新圖片">
                <input type="hidden" class="qq-edit-filename-selector" name="args[questionpicture]" tabindex="0" value="{x2;$question['questionpicture']}">
                </div>
                  </li>
                </ul>
                </div>
            </div>
          </script>
          <div class="fineuploader" attr-type="thumb" attr-template="pe-template-questionpicture"></div>
         </div>
         <label class="control-label col-sm-1"><p align="center">知識點</p></label>
             <div class="col-sm-11">
             <?php echo texteditor($form,$model, 'anstext1');?>
            </div>
        </div>
    </div>
</div>
        <div class="form-group">
            <label class="control-label col-sm-1"><p align="left">習題</p><p align="left">解析：</p></label>
            <div  id="answerbox_99" class="col-sm-11">
            <?php echo texteditor($form,$model, 'questiondescribe');?>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-sm-4"></label>
            <div class="col-sm-6">
        <button class="btn btn-primary" type="submit">提交</button>
        <input type="hidden" name="subjectid" value="<?php echo $model->subjectid;?>"/>
        <input type="hidden" name="questionid" value="<?php echo $model->questionid;?>"/>
        <input type="hidden" name="modify" value="1"/>
            </div>
        </div>
</fieldset>


     <table>
                    <tr class="table-title">
                        <td colspan="4">项目最终成果简介</td>
                    </tr>
                    <tr>

                        <td colspan="4">
                            <?php echo $form->textArea($model, 'question', array('class' => 'input-text', 'style'=>'width:97%;height:600px;resize:none','maxlength' => '6000','placeholder'=>"项目最终成果简介")); ?>
                            <?php echo $form->error($model, 'question', $htmlOptions = array()); ?>
                        </td>
                    </tr>
                           <tr id="show_cont_line"><!--news_type=225时显示-->
                        <td>
                            <?php echo $form->labelEx($model, 'question'); ?><br>
                            <p style="color: #808080">*前端文档显示样式，是根据后台编辑格式进行展示。</p>
                            <p style="color: #808080">*您可选择编辑器自带的模板或自定义进行编辑。</p>
                        </td>
                        <td colspan="3">
                            <?php echo $form->hiddenField($model, 'question_temp', array('class' => 'input-text')); ?>
                            <script>we.editor('<?php echo get_class($model);?>_question_temp', '<?php echo get_class($model);?>[question_temp]');</script>
                            <?php echo $form->error($model, 'question_temp', $htmlOptions = array()); ?>
                        </td>
                    </tr>
                </table>


</form>
        </div>
    </div>
<?php $this->endWidget();?>
        </div>
    </div>
</div>
</body>
<script type="text/javascript">
var sn1=0<?php echo $model->questiontype;?>;
var sn2=0<?php echo $model->answernum;?>
var subjectid=<?php echo $model->subjectid;?>;
if(sn1<=1) sn1=1;

setAnswerHtml_new(sn1,'answerbox');

function setAnswerHtml_new(t,o)
{   
    sn1=t;
    var sn=$("#args[questionselectnumbe]").find('option:selected').attr('rel');
    $("."+o).hide();
    $("#"+o+"_"+t).show();
    var sn0=parseInt(t);

    if(( sn0 >= 4) && ( sn0 <10) || ( sn0 <= 0))
    {
        $("#answerbox_5").show();
        show_answer();
        $("#selecttext").hide();
    }

    $("#selecttext").hide();
    if( sn0 == 10)
    {
        $("#answerbox_1").hide();   
    }
}

function setSelectnumber(sn0)
{
  sn2=sn0;
  setAnswerHtml_new(sn1,'answerbox');
}
function show_answer()
{
  if(sn2<=1) sn2=1;
  for(var i=1;i<9;i++){
    if(i<=sn2 || i==1 ) {
        $("#answerbox_5"+i).show();}
     else{
        $("#answerbox_5"+i).hide();
     }
  }
}

</script>

<script type="text/x-mathjax-config">
  MathJax.Hub.Config({tex2jax: {inlineMath: [['$','$'], ['\\(','\\)']]}});
</script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.2/MathJax.js?config=TeX-MML-AM_CHTML">
</script>

<script>
function select_chapters(obj)
{
    var lid=$('#levelid').val();
    var s2='';
    var s1='index.php?exam-master-questions-getChapters_ajx&subjectid='+subjectid
    s1=s1+'&levelid='+lid;
    $.getJSON(s1+'&'+Math.random(),
        function(data)
        {  
            s1="";
            for (i = 0; i < data.length; i++) {
                s2=data[i]['chapter'];
                s1=s1+"<option value='"+s2+"'";
                if(s2=="{x2;$question['chapter']}"){
                 s1=s1+" selected ";    
                }
                s1=s1+">"+s2+"</option>";
            } 
           $('#chapter').html(s1);
        //   select_part(obj);
        });
}


function select_part(obj)
{
    var lid=$('#levelid').val();
    var part=$('#chapter').val();
    var s1='index.php?exam-master-questions-getSections_ajx&subjectid='+subjectid
    s1=s1+'&levelid='+lid+'&chapter='+part;
    $.getJSON(s1+'&'+Math.random(),
        function(data)
        {  
           s1="";
            for (i = 0; i < data.length; i++) {
            s1=s1+"<option value='"+data[i]['sectionid']+"'";
            if(data[i]['sectionid']=="{x2;$question['sectionid']}"){
             s1=s1+" selected ";    
            }
            s1=s1+">"+data[i]['part']+'-'+data[i]['section']+"</option>";

            } 
            $('#sectionid').html(s1);
        });
}

</script>
</html>
